ROMA, 7 JUN (ANSA) - O chef italiano Massimo Bottura recebeu nesta quarta-feira (7) a medalha McKim, um prêmio anual da Academia Americana de Roma (AAR) destinado a homenagear personalidades que, com seu trabalho, contribuíram significativamente para as artes, humanidades e cultura.**

Criatividade

[Fonte](https://noticias.uol.com.br/ultimas-noticias/ansa/2023/06/07/bottura-e-premiado-por-ser-simbolo-da-criatividade-italiana.htm)
[Google](https://google.com.br)
[google](https://google.com.br)
[Uol](https://uol.com.br)

[Link da noticia do cheff italiano](https://noticias.uol.com.br/ultimas-noticias/ansa/2023/06/07/bottura-e-premiado-por-ser-simbolo-da-criatividade-italiana.htm)

Leonardo da Vinci era outro cidadão italiano muito Criativo