#inventores


---
home: true
---


# Onde nasceu Leonardo da Vinci?

---

"Ele nasceu em **15 de abril de 1452**, na [[Vila de Vinci]] na Toscana, na [[Itália]]. Leonardo era filho da camponesa ==Caterina Lippi== e do tabelião ***Piero da Vinci***, que não eram casados.

---

"Ele nasceu em **15 de abril de 1452**, na [[Vila de Vinci]] na Toscana, na [[Itália]]. Leonardo era filho da camponesa ==Caterina Lippi== e do tabelião ***Piero da Vinci***, que não eram casados.